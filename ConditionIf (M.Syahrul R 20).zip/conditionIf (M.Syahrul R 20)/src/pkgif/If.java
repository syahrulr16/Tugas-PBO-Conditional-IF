package pkgif;

public class If {

    public static void main(String[] args) {
                
        int a = 27;

        System.out.println("nilai = " + a);

        if (a % 2 == 0 ){

            System.out.println("ADALAH BILANGAN GENAP");
            
        } else {
            
            System.out.println("ADALAH BILANGAN GANJIL");
        }

      
    }
}